		<!-- Footer Section -->
<footer id="footer">
			<div class="footer-container">
			
				<div class="triangle"></div>
				<div id="scroll-to-top">
					<div class="scrollup">
						<i class="fa fa-arrow-up"></i>
					</div> 
				</div>

				<div class="container">
					<div class="row">
						<div class="footer-widget">
							<?php dynamic_sidebar('footer_left_sidebar');?>
							<?php dynamic_sidebar('footer_middle_sidebar');?>
							<?php dynamic_sidebar('footer_widget');?>
							
						</div><!-- /.footer-widget -->
					</div><!-- /.row -->
				</div><!-- /.container -->
				
			</div><!-- /.footer-container -->
		</footer><!-- /#footer -->
		<!-- Footer Section End -->

		<div class="copywright-footer text-center">
			<p> &copyRemix 2015 | All Rights Reserved, Developed By <a href="#">Mahmudul Hasan Selim</a></p>
		</div>

	<?php wp_footer();?>
	</body>
</html>