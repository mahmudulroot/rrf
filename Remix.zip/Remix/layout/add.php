        <div id="add-section" class="add-section"> 
	        <div class="overlay">
		        <div class="section-padding">
		            <div class="container">                
		                <div class="section-content text-center wow zoomIn" data-wow-duration=".5s" data-wow-delay=".6s">
		                   <h2>Remix is a awesome psd template</h2>
		                   <p class="section-description">Appropriately customize real-time expertise through adaptive human capital. Competently predominate standardized functionalities with excellent alignments.</p>

		                    <div class="link">
								<a href="#" class="btn btn-default">Get Started</a>
							</div>
		                </div><!-- /.section-content --> 
		            </div> 
		        </div><!-- /.section-padding -->
	        </div>
        </div><!-- /#add-section -->