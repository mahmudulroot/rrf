		<section id="video" class="video-section">
			<div class="overlay">
				<div class="section-padding">
					<div class="section-content text-center">
						<a href="https://www.youtube.com/embed/didkQXhjeVQ" class="boxer" title="Creative Video">
							<!-- <img class="wow bounceIn animated" data-wow-delay="0.6s" src="<?php echo esc_url(get_template_directory_uri());?>/images/play.png" alt="Play Image"> -->
							<em class="flaticon-musicplayer7 wow rollIn animated" data-wow-delay="0.6s"></em>
						</a>
					</div>
				</div>
			</div><!-- /.overlay -->
		</section><!-- /#video -->